const fs = require('fs')


exports.otw = fs.readFileSync('./temp/sticker/oke tunggu.webp')
exports.bad = fs.readFileSync('./temp/sticker/istighfar.webp')
exports.marah = fs.readFileSync('./temp/sticker/marah.webp')
exports.eror = fs.readFileSync('./temp/sticker/error.webp')
exports.paan = fs.readFileSync('./temp/sticker/why.webp')
exports.fuck = fs.readFileSync('./temp/sticker/pakyu.webp')
